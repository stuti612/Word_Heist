using UnityEngine;
using System.Collections.Generic;

public class LetterInventory : MonoBehaviour
{
    public static LetterInventory Instance;

    private Dictionary<char, int> letters = new Dictionary<char, int>();

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    public void AddLetter(char c)
    {
        if (letters.ContainsKey(c))
            letters[c]++;
        else
            letters[c] = 1;

        Debug.Log("Collected: " + c);
    }

    public Dictionary<char, int> GetLetters()
    {
        return letters;
    }
}
