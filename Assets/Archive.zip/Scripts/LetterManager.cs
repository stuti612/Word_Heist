using UnityEngine;

public class LetterManager : MonoBehaviour
{
    public GameObject letterPrefab;
    public PlatformLetterSpawner[] platforms;

    public string lettersToSpawn = "AEIRSTNO";

    void Start()
    {
        if (letterPrefab == null)
        {
            Debug.LogError("LetterPrefab NOT assigned in LetterManager!");
            return;
        }

        var letters = lettersToSpawn.ToUpper().ToCharArray();
        int index = 0;

        foreach (var p in platforms)
        {
            if (p == null) continue;
            if (index >= letters.Length) break;

            int take = Mathf.Min(p.spawnPoints.Length, letters.Length - index);
            char[] chunk = new char[take];

            for (int i = 0; i < take; i++)
                chunk[i] = letters[index++];

            p.Spawn(letterPrefab, chunk);
        }
    }
}
