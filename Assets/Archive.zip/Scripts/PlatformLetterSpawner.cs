using UnityEngine;

public class PlatformLetterSpawner : MonoBehaviour
{
    public Transform[] spawnPoints;

    private void Awake()
    {
        // Just a safety check for scene setup (spawn points assigned)
        if (spawnPoints == null || spawnPoints.Length == 0)
        {
            Debug.LogWarning($"{name}: No spawnPoints assigned on PlatformLetterSpawner.");
        }
    }

    public void Spawn(GameObject letterPrefab, char[] letters)
    {
        if (letterPrefab == null)
        {
            Debug.LogError($"{name}: LetterPrefab is NULL in Spawn()");
            return;
        }

        if (letters == null || letters.Length == 0)
        {
            Debug.LogWarning($"{name}: No letters passed to Spawn()");
            return;
        }

        if (spawnPoints == null || spawnPoints.Length == 0)
        {
            Debug.LogError($"{name}: spawnPoints is NULL/empty. Assign P0/P1/... in Inspector.");
            return;
        }

        int n = Mathf.Min(spawnPoints.Length, letters.Length);

        for (int i = 0; i < n; i++)
        {
            if (spawnPoints[i] == null)
            {
                Debug.LogError($"{name}: SpawnPoint at index {i} is NULL!");
                continue;
            }

            var obj = Instantiate(letterPrefab, spawnPoints[i].position, Quaternion.identity);

            var pickup = obj.GetComponent<LetterPickup>();
            if (pickup == null)
            {
                Debug.LogError($"{name}: LetterPickup component missing on prefab!");
                Destroy(obj);
                continue;
            }

            pickup.SetLetter(letters[i]);
        }
    }
}
