using UnityEngine;
using TMPro;

public class LetterPickup : MonoBehaviour
{
    public char letter;

    public void SetLetter(char c)
    {
        letter = c;
        GetComponentInChildren<TMP_Text>().text = c.ToString();
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            LetterInventory.Instance.AddLetter(letter);
            Destroy(gameObject);
        }
    }
}
